namespace DepthChart.Enums;

public enum SportType
{
    NFL
    , MLB
}