﻿using System;

namespace CodingTest.DepthCharts
{
    class Program
    {
        static void Main(string[] args)
        {
            
        }
    }
}
