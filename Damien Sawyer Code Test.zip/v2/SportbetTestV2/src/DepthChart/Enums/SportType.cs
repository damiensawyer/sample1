// (c) D. Sawyer <damiensawyer@gmail.com> 2025

namespace DepthChart.Enums;

public enum SportType
{
  NFL,
  MLB
}