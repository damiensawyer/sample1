// (c) D. Sawyer <damiensawyer@gmail.com> 2025

namespace DepthChart.Models;

public record Player(int PlayerId, string Name, string Position);