// (c) D. Sawyer <damiensawyer@gmail.com> 2025

namespace TestHelpers.DynamicFixtures;

public static class TestHelpers
{
  public static bool verboseLog = false;
}